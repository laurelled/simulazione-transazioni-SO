#ifndef _USER_H_
#define _USER_H_

void init_user(int shm_users_id, int shm_nodes_array_id, int shm_nodes_size_id, int shm_book_id, int shm_book_size_id);
#endif